package imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import dbconnection.Dbconnection;

import bean.Registerbean;
import bean.Uploadbean;
import inter.Inter;

public class Implement implements Inter {
	
	int result;
	boolean sel;
	
	
	

	@Override
	public int register(Registerbean rb) {
		Connection c;
		PreparedStatement ps;
		
		try {
			c=Dbconnection.createconnection();
			ps=c.prepareStatement("INSERT INTO splitting.register VALUES(?,?,?,?,?,?,?)");
			ps.setString(1,rb.getUsername());
			ps.setString(2,rb.getEmailid());
			ps.setString(3,rb.getMobilenumber());
			ps.setString(4,rb.getAge());
			ps.setString(5,rb.getGender());
			ps.setString(6,rb.getDistrict());
			ps.setString(7,rb.getPassword());
			
			result=ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}


	@Override
	public int login(Registerbean lb) {
		Connection c;
		PreparedStatement ps;
		
		try {
			c=Dbconnection.createconnection();
			ps=c.prepareStatement("SELECT id FROM splitting.register r where username='"+lb.getUsername()+"' and password='"+lb.getPassword()+"'");
			ResultSet rs=ps.executeQuery();
			
			
			rs.next();
			int id = rs.getInt(1);
			return id;
			
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}


	@Override
	public int upload(Uploadbean ub) {
		Connection c;
		PreparedStatement ps;
		
		
		
		try {
			
			c=Dbconnection.createconnection();
			ps=c.prepareStatement("INSERT INTO splitting.upload  VALUES(?,?,?,?,?,?,?,?,?)");
			
			
			
			ps.setString(1,ub.getFilename());
			
			ps.setString(2,ub.getSinger());
			ps.setString(3,ub.getMusic());
			ps.setString(4,ub.getFilefullpath());
			ps.setString(5,ub.getFiletype());			
			ps.setLong(6,ub.getFilesize());
			ps.setString(7,ub.getFullcontent());
			ps.setString(8,ub.getLanguage());
			ps.setString(9, ub.getGroup());
			
			result=ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
