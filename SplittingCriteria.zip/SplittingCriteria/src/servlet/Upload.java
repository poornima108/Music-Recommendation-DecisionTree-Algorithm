package servlet;

import imple.Implement;
import inter.Inter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Uploadbean;
import com.oreilly.servlet.multipart.FilePart;
import com.oreilly.servlet.multipart.MultipartParser;
import com.oreilly.servlet.multipart.ParamPart;
import com.oreilly.servlet.multipart.Part;

/**
 * Servlet implementation class Upload
 */
@WebServlet("/Upload")
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Upload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MultipartParser mp=new MultipartParser(request,999999999);
		
		Part p;
		FilePart fp;
		ArrayList<String> ar=new ArrayList<String>();
		
	    String filepath1=null;
	    String filecontent = "";

		HttpSession projecthead=request.getSession();
		String head=(String)projecthead.getAttribute("projecthead");
		
		String filename = "";
		
		long size = 0;
		String filetype="";
		
		
		String path=getServletContext().getRealPath("");
		
		String editpath=path.substring(0,path.indexOf("."));
		
		String fullpath=editpath+"SplittingCriteria\\WebContent\\Fileupload\\"+filename;
		
		
		
		
		
		
		
		
		while ((p=mp.readNextPart())!=null) {
			if(p.isFile()){
				
				fp=(FilePart) p;
				
				filename=fp.getFileName();
				
				filepath1=fullpath+filename;
				
				File file=new File(filepath1);
				size=fp.writeTo(file);		
				
				filetype=fp.getContentType();
				
				
				
			}
			else if(p.isParam()){
				 ParamPart paramPart = (ParamPart) p;
		            String value = paramPart.getStringValue();
		            ar.add(value);
			}
			
			if (filename.endsWith(".txt")) {
				FileInputStream fis = new FileInputStream(filepath1);
				
				byte[] b = new byte[fis.available()];
				fis.read(b);
				String reading = new String(b);
				filecontent = filecontent + reading;
				fis.close();
			}
		}
		
		
		
		Uploadbean ub=new Uploadbean();
		ub.setFileowner(head);
		
		ub.setFilename(filename);
		ub.setFilefullpath(filepath1);
		ub.setFiletype(filetype);
		ub.setFilesize(size);
		ub.setFullcontent(filecontent);
		
		ub.setLanguage(ar.get(0).toString());
		ub.setSinger(ar.get(1).toString());
		ub.setMusic(ar.get(2).toString());
		ub.setGroup(ar.get(3).toString());
		
		
		Inter i=new Implement();
		int j=i.upload(ub);
		
		if (j==1) {
			response.sendRedirect("musiclauncher.jsp");
			
		} else {
			response.sendRedirect("failed");
		}
	}
}
