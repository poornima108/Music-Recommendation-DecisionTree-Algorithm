package servlet;

import imple.Implement;
import inter.Inter;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Registerbean;


/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Register() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String s1=request.getParameter("username");	
		
		String s2=request.getParameter("emailid");	
		
		String s3=request.getParameter("mobilenumber");	
		
		String s4=request.getParameter("age");	
				
		String s5=request.getParameter("gender");	
		
		String s6=request.getParameter("district");	
		
		String s7=request.getParameter("password");	
		
		
		Registerbean rb=new Registerbean();
		rb.setUsername(s1);
		rb.setEmailid(s2);
		rb.setMobilenumber(s3);
		rb.setAge(s4);
		rb.setGender(s5);
		rb.setDistrict(s6);
		rb.setPassword(s7);
		
		Inter i=new Implement();
		int j=i.register(rb);
		
		
		if (j==1) {
			response.sendRedirect("login.jsp");
			
		} else {
			response.sendRedirect("failed");

		}
		
		
		
		
	}

	

}
