package inter;

import bean.Registerbean;
import bean.Uploadbean;

public interface Inter {

	int register(Registerbean rb);

	int login(Registerbean lb);

	int upload(Uploadbean ub);

}
