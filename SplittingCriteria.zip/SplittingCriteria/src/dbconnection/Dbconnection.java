package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbconnection {
	
	static Connection c;

	public static Connection createconnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			c=DriverManager.getConnection("jdbc:mysql://localhost:3306/splitting","root","root");
			System.out.println("Database is Connected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return c;
	}
}
